import React, { Component } from 'react'

export class PassImage extends Component {
    render() {
        return (
            <div>
                
            </div>
        )
    }
}

export default PassImage
