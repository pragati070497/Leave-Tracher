import React from 'react'

export default function Practice() {
    return (
        <div>
            
        </div>
    )
}
