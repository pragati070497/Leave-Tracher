import React, { Component } from 'react'

export class ImageTest extends Component {

  
    render() {
        return (
            <div>
                <img src={require('D:/MiniProject/project/src/pro.jpg')} /><br></br>
              
            </div>
        )
    }
}

export default ImageTest
